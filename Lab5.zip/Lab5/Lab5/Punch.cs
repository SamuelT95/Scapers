﻿using gameProject;
using Lab5;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5
{
    public class Punch : Attack
    {
        internal override string Name { get; set; }
        internal override int Damage { get; set; }
        internal override float FailureRate { get; set; }

        public Punch()
        {
            Name = "Punch";
            Damage = 4;
            FailureRate = 0;
        }
    }
}
