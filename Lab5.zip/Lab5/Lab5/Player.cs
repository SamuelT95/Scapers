﻿using SFML.Graphics;
using SFML.System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gameProject
{
    public class Player : Character
    {

        public Player() 
        {
            //player specific property values
            _shape = new RectangleShape(new Vector2f(50.0f, 50.0f));
            _shape.FillColor = Color.White;
            _name = "Squiggles";
            _maxHealth = 20;
            _health = MaxHealth;
            _moveSpeed = 10;
            _attacks = new List<Attack>();

            //ADD ATTACKS HERE
        }
    }
}
