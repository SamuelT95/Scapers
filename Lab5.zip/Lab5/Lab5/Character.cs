﻿using SFML.Graphics;
using SFML.System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gameProject
{
    /// <summary>
    /// An abstract class from which to base players or enemies off
    /// </summary>
    abstract public class Character : Drawable
    {
        internal Shape _shape;
        internal string _name;
        internal int _health;
        internal int _maxHealth;
        internal int _moveSpeed;
        internal List<Attack> _attacks;

        public FloatRect Bounds { get { return _shape.GetGlobalBounds(); } }   
        public string Name { get { return _name; } }
        public int Health { get { return _health; } }
        public int MaxHealth { get { return _maxHealth; } }
        public int MoveSpeed { get { return _moveSpeed; } set { _moveSpeed = value; } }
        public Vector2f Position { get { return _shape.Position; } }
        public List<Attack> Attacks { get { return _attacks; } }

        /// <summary>
        /// Just a pass through so this object can be "Drawn"
        /// </summary>
        /// <param name="target"></param>
        /// <param name="states"></param>
        public void Draw(RenderTarget target, RenderStates states)
        {
            _shape.Draw(target, states);
        }

        /// <summary>
        /// Moves the character by the specified amounts
        /// </summary>
        /// <param name="amount"></param>
        public void Move(Vector2f amount)
        {
            _shape.Position += amount;
        }

        /// <summary>
        /// Moves the character by the specified amounts
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        public void Move(float x, float y)
        {
            _shape.Position += new Vector2f(x, y);
        }

        /// <summary>
        /// Moves the player to the specified location
        /// </summary>
        /// <param name="position"></param>
        public void MoveTo(Vector2f position)
        {
            _shape.Position = position;
        }

        /// <summary>
        /// Move the player to the specfied location
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        public void MoveTo(float x, float y)
        {
            _shape.Position = new Vector2f(x, y);
        }

        /// <summary>
        /// Damages the player based on the specified attack
        /// </summary>
        /// <param name="attack"></param>
        /// <returns></returns>
        public bool Takedamage(Attack attack)
        {
            Random random = new Random();
            double rFloat = random.NextDouble();

            if (rFloat < attack.FailureRate )
            {
                return true;
            }

            _health -= attack.Damage;

            if(Health <= 0)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Heals the player by the specified amount
        /// </summary>
        /// <param name="amount"></param>
        public void Heal(int amount)
        {
            while(Health < MaxHealth && amount != 0) 
            {
                _health++;
                amount--;
            }
        }
        
        /// <summary>
        /// Moves the player incrementally towards the specified position 
        /// </summary>
        /// <param name="pos"></param>
        /// <returns></returns>
        public bool moveTowards(Vector2f pos)
        {
            float distX = MathF.Abs(pos.X - _shape.Position.X);
            float distY = MathF.Abs(pos.Y - _shape.Position.Y);

            float angle = MathF.Atan(distY / distX);

            float moveDistY = MathF.Sin(angle) * MoveSpeed;
            float moveDistX = MathF.Sqrt(MathF.Pow(MoveSpeed, 2) - MathF.Pow(moveDistY, 2));

            if(_shape.Position.X > pos.X)
            {
                moveDistX *= -1;
            }

            if(_shape.Position.Y > pos.Y)
            {
                moveDistY *= -1;
            }

            Move(moveDistX, moveDistY);
            return true;
        }
    }
}
