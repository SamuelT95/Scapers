﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gameProject
{
    abstract public class Attack
    {
        abstract internal string Name { get; set; }
        abstract internal int Damage { get; set; }
        abstract internal float FailureRate { get; set; }
    }
}
