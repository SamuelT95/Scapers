using Lab5;
using gameProject;
using SFML.System;
using System.Numerics;

/// <summary>
/// Lab 5 Unit testing
/// Authors: Traill Lyall
/// Date: Feb 28, 2023 Revision: 1
/// Sources:
/// </summary>
namespace PlayerTest
{
    [TestClass]
    public class PlayerTest
    {
        [TestMethod]
        public void TestMoveTo()
        {
            Player player = new Player();

            player.MoveTo(100, 200);

            Assert.AreEqual(player.Position.X, 100);
            Assert.AreEqual(player.Position.Y, 200);
        }

        [TestMethod]
        public void TestMove()
        {
            Player player = new Player();

            player.Move(5, 10);

            Assert.AreEqual(player.Position.X, 5);
            Assert.AreEqual(player.Position.Y, 10);
        }

        [TestMethod]
        public void TestTakeDamage()
        {
            Player player = new Player();

            player.Takedamage(new Punch());
            Assert.AreEqual(player.Health, 16);

            player.Takedamage(new Punch());
            player.Takedamage(new Punch());
            player.Takedamage(new Punch());
            Assert.IsFalse(player.Takedamage(new Punch()));
        }

        [TestMethod]
        public void TestHeal()
        {
            Player player = new Player();

            player.Takedamage(new Punch());
            player.Takedamage(new Punch());

            player.Heal(10);

            Assert.AreEqual(player.Health, 20);
        }

        [TestMethod]
        public void TestMoveTowards()
        {
            Player player = new Player();

            Vector2f target = new Vector2f(100, 200);

            float xDist = player.Position.X - target.X;
            float yDist = player.Position.Y - target.Y;

            float distanceToTarget = MathF.Sqrt(MathF.Pow(xDist, 2) + MathF.Pow(yDist, 2));

            player.moveTowards(target);

            xDist = player.Position.X - target.X;
            yDist = player.Position.Y - target.Y;
            float newDistanceToTarget = MathF.Sqrt(MathF.Pow(xDist, 2) + MathF.Pow(yDist, 2));

            Assert.IsTrue(newDistanceToTarget < distanceToTarget);
        }
    }
}